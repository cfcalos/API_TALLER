const express = require('express');
const router = express.Router();
const db = require('../db');

// Obtener todos los artefactos
router.get('/', async (req, res) => {
  const [rows] = await db.query('SELECT * FROM artefacto');
  res.json(rows);
});

// Obtener artefacto por ID
router.get('/:id', async (req, res) => {
  const [rows] = await db.query('SELECT * FROM artefacto WHERE id = ?', [req.params.id]);
  res.json(rows[0]);
});

// Crear un nuevo artefacto
router.post('/', async (req, res) => {
  const { idCliente, serie, marca, modelo, categoria, descripcion } = req.body;
  const [result] = await db.query(
    'INSERT INTO artefacto (idCliente, serie, marca, modelo, categoria, descripcion) VALUES (?, ?, ?, ?, ?, ?)',
    [idCliente, serie, marca, modelo, categoria, descripcion]
  );
  res.json({ id: result.insertId });
});

// Actualizar un artefacto
router.put('/:id', async (req, res) => {
  const { idCliente, serie, marca, modelo, categoria, descripcion } = req.body;
  await db.query(
    'UPDATE artefacto SET idCliente = ?, serie = ?, marca = ?, modelo = ?, categoria = ?, descripcion = ? WHERE id = ?',
    [idCliente, serie, marca, modelo, categoria, descripcion, req.params.id]
  );
  res.sendStatus(204);
});

// Eliminar un artefacto
router.delete('/:id', async (req, res) => {
  await db.query('DELETE FROM artefacto WHERE id = ?', [req.params.id]);
  res.sendStatus(204);
});

module.exports = router;